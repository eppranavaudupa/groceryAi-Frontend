"use client"

import { useState, useRef, useEffect } from "react"
import AudioButton from "@/components/audio-button"
import TranscriptDisplay from "@/components/transcript-display"
import StatusIndicator from "@/components/status-indicator"

export default function Home() {
  const [transcript, setTranscript] = useState("")
  const [apiResponse, setApiResponse] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [status, setStatus] = useState("ready") // ready, recording, processing, done, error
  const [error, setError] = useState("")
  const recognitionRef = useRef<any>(null)
  const synthRef = useRef(window.speechSynthesis)

  // Initialize Web Speech API
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition

    if (!SpeechRecognition) {
      setStatus("error")
      setError("Speech Recognition is not supported in this browser")
      return
    }

    const recognition = new SpeechRecognition()
    recognition.continuous = false
    recognition.interimResults = false
    recognition.lang = "en-US"

    recognition.onresult = (event: any) => {
      let finalTranscript = ""
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript
        }
      }
      if (finalTranscript) {
        setTranscript(finalTranscript)
        announceToScreenReader(`Heard: ${finalTranscript}`)
        sendToAPI(finalTranscript)
      }
    }

    recognition.onerror = (event: any) => {
      setStatus("error")
      setError(`Speech recognition error: ${event.error}`)
      announceToScreenReader(`Error: ${event.error}`)
    }

    recognitionRef.current = recognition

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
  }, [])

  const startRecording = () => {
    if (!recognitionRef.current) return

    try {
      setIsRecording(true)
      setStatus("recording")
      setError("")
      setTranscript("")
      setApiResponse("")
      recognitionRef.current.start()
      announceToScreenReader("Recording started. Speak now.")
    } catch (err) {
      setStatus("error")
      setError("Failed to start recording")
    }
  }

  const stopRecording = () => {
    if (!recognitionRef.current) return

    try {
      recognitionRef.current.stop()
      setIsRecording(false)
    } catch (err) {
      setStatus("error")
      setError("Failed to stop recording")
    }
  }

  const sendToAPI = async (prompt: string) => {
    setStatus("processing")
    announceToScreenReader("Sending to server...")

    try {
      const response = await fetch("http://localhost:5000/ai", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_prompt: prompt,
        }),
      })

      if (!response.ok) {
        throw new Error("API request failed")
      }

      const data = await response.json()
      console.log("[v0] API Response:", data)

      // Extract response text
      const responseText = data.response || data.text || JSON.stringify(data)
      setApiResponse(responseText)
      setStatus("done")
      announceToScreenReader("Got response. Converting to speech.")

      speakResponse(responseText)
    } catch (err: any) {
      setStatus("error")
      setError(`Failed to get response: ${err.message}. Make sure the API server is running.`)
      announceToScreenReader(`Error: ${err.message}`)
    }
  }

  const speakResponse = (text: string) => {
    if (!synthRef.current) return

    // Cancel any ongoing speech
    synthRef.current.cancel()

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = 1
    utterance.pitch = 1
    utterance.volume = 1

    utterance.onstart = () => {
      announceToScreenReader("Speaking response...")
    }

    utterance.onend = () => {
      announceToScreenReader("Done. Ready for next input.")
      setStatus("ready")
    }

    utterance.onerror = (event: any) => {
      setStatus("error")
      setError(`Speech synthesis error: ${event.error}`)
      announceToScreenReader(`Error: ${event.error}`)
    }

    synthRef.current.speak(utterance)
  }

  const announceToScreenReader = (message: string) => {
    const announcement = document.createElement("div")
    announcement.setAttribute("role", "status")
    announcement.setAttribute("aria-live", "polite")
    announcement.setAttribute("aria-atomic", "true")
    announcement.textContent = message
    announcement.className = "sr-only"
    document.body.appendChild(announcement)

    setTimeout(() => {
      document.body.removeChild(announcement)
    }, 1000)
  }

  // Handle Enter key press and release
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Enter" && !isRecording) {
        e.preventDefault()
        startRecording()
      }
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === "Enter" && isRecording) {
        e.preventDefault()
        stopRecording()
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
    }
  }, [isRecording])

  return (
    <main className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="flex flex-col items-center justify-center gap-8 w-full max-w-md">
        {/* Status Indicator */}
        <StatusIndicator status={status} />

        {/* Title */}
        <h1 className="sr-only">Audio Input Assistant</h1>
        <p className="text-center text-muted-foreground text-lg">
          Press and hold <kbd className="font-semibold text-foreground">Enter</kbd> to record
        </p>

        {/* Large Audio Button */}
        <AudioButton isRecording={isRecording} onClick={isRecording ? stopRecording : startRecording} />

        {/* Transcript Display */}
        {transcript && <TranscriptDisplay transcript={transcript} label="You said:" />}

        {/* API Response Display */}
        {apiResponse && <TranscriptDisplay transcript={apiResponse} label="Response:" />}

        {/* Error Message */}
        {error && (
          <div
            className="p-4 bg-destructive/10 border border-destructive text-destructive rounded-lg w-full text-center"
            role="alert"
          >
            {error}
          </div>
        )}

        {/* Instruction Text */}
        <p className="text-center text-sm text-muted-foreground">
          {status === "ready" && "Ready to record. Press and hold Enter or click the button."}
          {status === "recording" && "Recording... Release to stop."}
          {status === "processing" && "Processing your request..."}
          {status === "done" && "Done! Listen to the response or press Enter again."}
          {status === "error" && "An error occurred. Please try again."}
        </p>
      </div>
    </main>
  )
}
